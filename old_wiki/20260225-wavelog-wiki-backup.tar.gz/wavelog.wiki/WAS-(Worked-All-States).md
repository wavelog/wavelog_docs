Within the WAS-Award page you can find an overview on your actual WAS-count. Each WAS is listed with it's bands worked on.

The list contains all worked (confirmed and unconfirmed) US States.