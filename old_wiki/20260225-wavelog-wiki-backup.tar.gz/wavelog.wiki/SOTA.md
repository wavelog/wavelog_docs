Within the SOTA-Award page you can find an overview on your actual SOTA-count. Each SOTA-reference is listed with it's QSOs worked on.
