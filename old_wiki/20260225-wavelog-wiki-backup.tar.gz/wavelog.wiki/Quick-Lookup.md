Quick Lookup was made so that you quickly can check what you have worked on which band and mode.
To use Quick Lookup, use Alt-L to get the dialog.

You can then search the following:
* CQ Zone
* DXCC
* Gridsquare
* IOTA
* SOTA
* US State
* WWFF
* LoTW user

