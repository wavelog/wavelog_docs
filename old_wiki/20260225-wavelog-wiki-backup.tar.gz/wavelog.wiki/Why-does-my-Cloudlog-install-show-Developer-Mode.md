To change this, edit index.php and set:

define('ENVIRONMENT', 'production');