First time you enter to Wavelog, you have to use the demo user, that's it, "**_m0abc_**" as user and "_**demo**_" as password.

Inside this demo user, you can create your real user, normally your callsign and a password, using the "Accounts" option on the "Admin" menu. This will be the account you are going to use normally. 

In your account you can create different Station Profiles for your different locations or callsigns.