## My theme reset to default!
If you were using a theme other than the default light one, you'll find that your preference was reset to default due to a change in the way that Wavelog manages themes. To switch back to another theme, click on your username at the top-right of the menu bar (next to the user icon) and select Account. On the Edit Account page, choose another theme from the Stylesheet drop-down menu.

The old "Dark" theme is now "Cyborg (Dark)". All other themes retained their original names. You'll see some new themes available to try as well.

Note: This change occurred with database migration 57.