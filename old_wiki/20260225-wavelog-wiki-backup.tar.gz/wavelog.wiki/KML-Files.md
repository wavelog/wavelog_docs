Its possible to create KML Outputs. These are stored within the /kml folder.

* You'll find it under Admin and KML export. It's possible to choose dates, mode, band, dxcc, cqzone and propagation mode.
