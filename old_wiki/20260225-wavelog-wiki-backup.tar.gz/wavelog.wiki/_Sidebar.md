# Contents

## Introduction

* [What is wavelog?](https://github.com/wavelog/wavelog/wiki/Wavelog-at-a-glance)

## Installation

* [Installation on Linux server](https://github.com/wavelog/Wavelog/wiki/Installation)
    * [Raspberry Pi with Diet Pi](https://github.com/wavelog/Wavelog/wiki/Installation-on-a-Raspberry-Pi-using-Diet-Pi-Distro)
    * [FreeBSD server](https://github.com/wavelog/Wavelog/wiki/Installation-on-a-Raspberry-Pi-using-Diet-Pi-Distro)
    * [OpenBSD server](https://github.com/wavelog/Wavelog/wiki/Installation-on-an-OpenBSD-Server)
    * [Recommended Cron Jobs and Cronmanager](https://github.com/wavelog/wavelog/wiki/Recommended-Cron-Jobs-and-Cronmanager)
    * [[Webserver Configurations]]
* [Installation on Windows server](https://github.com/wavelog/Wavelog/wiki/Installation-on-Windows-Server-(WAMP))
* [Installation via Docker](https://github.com/wavelog/wavelog/wiki/Installation-via-Docker)

### Updating

* [Updating Wavelog](https://github.com/wavelog/Wavelog/wiki/Updating)

### Global configuration

* [wavelog.php Config](https://github.com/wavelog/Wavelog/wiki/Wavelog.php-Configuration-File)
* [config.php Config](https://github.com/wavelog/wavelog/wiki/config.php-Configuration-file)
    * [[Multi Domain Instance Config]]

### Others

* [Hints & Tips](https://github.com/wavelog/Wavelog/wiki/Hints-&-Tips)
* [Migrate Cloudlog to Wavelog](https://github.com/wavelog/Wavelog/wiki/How-to-migrate-Cloudlog-to-Wavelog)
* [[HTTPS Support]]

## Usage
* [[Dashboard]]
* [[Logbook]]
* [[DXCluster]]
* [[DXWaterfall]]
* [[Logging]]
    * [[Contesting]]
    * [[QSO details]]
    * [[SimpleFLE]]
* [[Notes]]
* [[Analytics]]
* [[Awards]]
* [[Search]]
* [[Label-Printing]]
* [[Widgets]]
    * [[Static Map Images]]
    * [[On Air Widget]]
    * [OQRS Widget](https://github.com/wavelog/wavelog/wiki/OQRS-(Online-Qsl-Request-System)#add-iframe-of-oqrs-request)
    * [[Last QSOs Widget]]

## Administration

* [[Authentication]]
* [[QSO Modes]]
* [[Backup]]
* [[Update Country Files]]
* [[User Accounts]]
* [[Global Options]]
    * [[Maptile Server]]
    * [[Version Info]]
    * [[Hams-Of-Note]]
* [[Debug]]
    * [[Centralized Userdata]]
* [[Maintenance Mode]]
* [Migrate servers](https://github.com/wavelog/wavelog/wiki/Server-migration)


## User Options
* [[API]]
* [[Station Profiles]]
  * [Details about Station Profiles/Locations](https://github.com/wavelog/wavelog/wiki/Station-Profiles---Locations.-a-deeper-look)
* [Radio Interface](https://github.com/wavelog/Wavelog/wiki/Radio-Interface)
* [[ADIF Import / Export]]
* [Logbook of The World](https://github.com/wavelog/Wavelog/wiki/LoTW-Import-&-Export-Documentation)
* [[eQSL]]
* [[Print Requested QSLs]]
* [[Clublog Upload]]
* [QRZ Logbook](https://github.com/wavelog/Wavelog/wiki/QRZ-Logbook-Synchronisation)
* [KML Export](https://github.com/wavelog/Wavelog/wiki/KML-Files)

## Logbook / Callbook Integrations
* [Callbook (HamQTH, QRZ) Integration](https://github.com/wavelog/Wavelog/wiki/Callsign-Lookup)
* [Club Log Integration](https://github.com/wavelog/Wavelog/wiki/Setup-Club-Log-Integration)
* [DARC-DCL Integration](https://github.com/wavelog/wavelog/wiki/DARC-DCL%E2%80%90Connector)
* [QRZ Logbook](https://github.com/wavelog/Wavelog/wiki/QRZ-Logbook-Synchronisation)
* [log4OM](https://github.com/wavelog/Wavelog/wiki/log4OM)
* [[WSJT X Integration]]
* [Third Party Tools](https://github.com/wavelog/Wavelog/wiki/Third-Party-Tools)

## Clubstations
* [Recommended Setup for Special Callsigns and Clubs](https://github.com/wavelog/wavelog/wiki/Recommended-Setup-for-Special-Callsigns-and-Clubs)
* [Clubstations Overview](https://github.com/wavelog/wavelog/wiki/Clubstations)

## Troubleshooting
* [[Theme Issues]]
* [[Migration is locked]]
* [ADIF Import issues](https://github.com/wavelog/wavelog/wiki/ADIF-file-can't-be-imported)
* [Error logging](https://github.com/wavelog/wavelog/wiki/Error-logging)
* [LoTW FAQ](https://github.com/wavelog/wavelog/wiki/Logbook-of-The-World-(LoTW))
* [P12 file Upload](https://github.com/wavelog/wavelog/wiki/LoTW-P12-file-%E2%80%90-Not-possible-to-upload)

## Developer Information
* [Development-Notes](https://github.com/wavelog/wavelog/wiki/Development-Notes)
* [KML Files](https://github.com/wavelog/wavelog/wiki/KML-Files)
* [APIs](https://github.com/wavelog/wavelog/wiki/API)
* [[Translations]]
* [License](https://github.com/wavelog/Wavelog/blob/master/LICENSE)

## FAQ (Frequently Asked Questions)
* [ADIF file can't be imported](ADIF-file-can't-be-imported)
* [Enable error logging](Error-logging)
* [Logbook-of-The-World-(LoTW)](https://github.com/wavelog/wavelog/wiki/Logbook-of-The-World-(LoTW))
* [No realtime QSO upload when logging QSOs via API](https://github.com/wavelog/wavelog/wiki/No-realtime-QSO-upload-when-logging-QSOs-via-API)