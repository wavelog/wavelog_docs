Within the WAP-Award page you can find an overview of your actual WAP-count. Each Dutch province is listed with it's bands worked on.

The list contains all worked provinces.

Please note that the abbreviations are those used in Dutch contests and in daily (not necessarily HAM) communications within the Netherlands. The ADIF 3.1.5 standard talks about GE, LI and ZE where in daily practice and during radio contests these are GD, LB and ZL.

WAP-Award certificates are issued by the VRZA, one of the two national radio amateur associations in the Netherlands.