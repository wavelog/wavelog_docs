Widgets are little gadgets/add-ons, which can be embedded i.e. on websites and third-party services.

* [[Static Map Images]]
* [[On-Air Widget]]
* [OQRS Widget](https://github.com/wavelog/wavelog/wiki/OQRS-(Online-Qsl-Request-System)#add-iframe-of-oqrs-request)
* [[Last QSOs Widget]]