QRB Calculator was made so that you can check the distance and heading between gridsquares.
It will also show the path on a map. To bring it up, use Alt-Q.

It has also been integrated into the logbook and the qso dialog. If you click on the globe icon, the dialog will also pop up.