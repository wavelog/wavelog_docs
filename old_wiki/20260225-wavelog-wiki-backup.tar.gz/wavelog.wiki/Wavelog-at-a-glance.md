## What is it?
- Your new primary logbook.
- Self-hosted.
- Multi-User prepared/enabled (install, invite your friends/clubmembers)
- Reachable from anywhere with any browsing device.
- Central hub for **your** QSOs.
- Distribute QSOs from one platform to third-party QSL services.
- Many features, to name a few:
  - Permissionmanagement for Clubstations
  - Powerful analytics.
  - Maps for worked entities (DXCC, Grid, States, etc.).
  - APIs for third-party tools.
  - QSL management with label-printing function.
  - Powerful SAT tools (tracking, logging, etc.).
  - Award checking (based on your logged QSOs).
  - Create maps for your homepage; keep track of recent QSOs.
  - Widgets for your homepage.
  - Callbook lookup.
  - Many more features.

## What is it not?
- Not a QSL service.
- Not a QSO dumpster.
- Not a service you "back up your QSOs" to.
- Not a service where you can automatically import QRZ, LoTW, or eQSL QSOs that are not in your log.