# Welcome to the Wavelog Wiki!
## Wavelog at a glance
[A short summary about "What is Wavelog? What isn't it?"](https://github.com/wavelog/wavelog/wiki/Wavelog-at-a-glance)

## User Guide

### Preamble

Wavelog sits on top of a web server, commonly known as [LAMP](https://en.wikipedia.org/wiki/LAMP_%28software_bundle%29) which includes the **L**inux operating system along with the **A**pache web server, **M**ySQL relational database, and the **P**HP language. It should be noted that anyone hosting Wavelog without a good knowledge of LAMP, and troubleshooting errors, may struggle as Wavelog is an interface that uses the AMP services. 

Hosting options are available at a small cost where LAMP administration and Wavelog updates are managed by the hosting company. 
* **Install Guides**
    * [Installation on a Linux Server](https://github.com/wavelog/Wavelog/wiki/Installation)
    * [Installation on a Windows Server](https://github.com/wavelog/Wavelog/wiki/Installation-on-Windows-Server-(WAMP))
    * [Installation on a Raspberry Pi with Diet Pi](https://github.com/wavelog/Wavelog/wiki/Installation-on-a-Raspberry-Pi-using-Diet-Pi-Distro)
    * [Installation on a FreeBSD Server](https://github.com/wavelog/Wavelog/wiki/Installation-on-a-FreeBSD-Server)
    * [Installation on an OpenBSD Server](https://github.com/wavelog/Wavelog/wiki/Installation-on-an-OpenBSD-Server)
    * [Installation via Docker](https://github.com/wavelog/wavelog/wiki/Installation-via-Docker)

* [Updating](https://github.com/wavelog/Wavelog/wiki/Updating)
* [Hints & Tips](https://github.com/wavelog/Wavelog/wiki/Hints-&-Tips)
* **Configuration**
    * [wavelog.php Config](https://github.com/wavelog/Wavelog/wiki/Wavelog.php-Configuration-File)
    * [[Recommended Cron Jobs and Cronmanager]]
* **Administration**
    * [[Authentication]]
    * [[Clublog Upload]]
    * [[Backup]]
    * [[Update Country Files]]
    * [[Debug]]
    * [[Password Reset]]
* **User Dropdown**
    * [[API]]
    * [[Station Profiles]]
        * [A deeper look into station-profiles](https://github.com/wavelog/wavelog/wiki/Station-Profiles---Locations.-a-deeper-look)
    * [[QSO Modes]]
    * [[Contesting]]
    * [Radio Interface](https://github.com/wavelog/Wavelog/wiki/Radio-Interface)
    * [[ADIF Import / Export]]
    * [Logbook of The World](https://github.com/wavelog/Wavelog/wiki/LoTW-Import-&-Export-Documentation)
    * [[eQSL]]
    * [[OQRS (Online Qsl Request System)]]
    * [[Print Requested QSLs]]
    * [[SOTA CSV Export]]
* [[Dashboard]]
* [[Logbook]]
    * [[Advanced Logbook]]
* [[Logging]]
    * [[Contesting]]
        * [Post-contest workflow using the CBR importer](https://github.com/wavelog/wavelog/wiki/Post%E2%80%90Contest-workflow-%E2%80%90-the-CBR-importer)
        * [Why you need to import your cabrillo file AFTER your ADIF](https://github.com/wavelog/wavelog/wiki/CBR%E2%80%90Import-%E2%80%90-Why-we-need-to-import-ADIF-first,-then-CBR-later)
    * [[QSO details]]
    * [[SimpleFLE]]
* [[Notes]]
* [[Analytics]]
* [[Awards]]
* [[Search]]
* [[Label-Printing]]
* [[Quick Lookup]]
* [QRB Calculator](https://github.com/wavelog/Wavelog/wiki/QRB-Calculator-(V2-only))
* [[Themes]]
* [Winkey](https://github.com/wavelog/wavelog/wiki/Winkey)


## Logbook/Callbook Integrations
* [Callbook (HamQTH, QRZ) Integration](https://github.com/wavelog/Wavelog/wiki/Callsign-Lookup)
* [Club Log Integration](https://github.com/wavelog/Wavelog/wiki/Setup-Club-Log-Integration)
* [QRZ Logbook](https://github.com/wavelog/Wavelog/wiki/QRZ-Logbook-Synchronisation)
* [HRDLOG.net](https://github.com/wavelog/Wavelog/wiki/HRDLOG.net)
* [Third Party Tools](https://github.com/wavelog/Wavelog/wiki/Third-Party-Tools)

## Developer Information

* Developers
    * [[Development-Notes]]
    * [[KML-Files]]
    * [[API]]

### Future Development
* [REST Hardware Interface](https://github.com/wavelog/Wavelog/wiki/Remote-Interfaces)

## FAQ (Frequently Asked Questions)
* [ADIF file can't be imported](ADIF-file-can't-be-imported)
* [Enable error logging](Error-logging)
* [Logbook-of-The-World-(LoTW)](https://github.com/wavelog/wavelog/wiki/Logbook-of-The-World-(LoTW))
* [No realtime QSO upload when logging QSOs via API](https://github.com/wavelog/wavelog/wiki/No-realtime-QSO-upload-when-logging-QSOs-via-API)