Within the WAS-Award page you can find an overview on your actual WAS-count. Each state is listed with it's bands worked on.

The list contains all worked states.

One of the questions that keep coming up, is that Hawaii and Alaska is not included. These are counted as separate DXCC's, but they are not included in the list if state is not set on each QSO.