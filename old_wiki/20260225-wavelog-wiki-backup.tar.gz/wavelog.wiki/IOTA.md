Within the IOTA-Award page you can find an overview on your actual IOTA-count. Each IOTA is listed with it's bands worked on.

The list contains all worked (confirmed and unconfirmed) IOTAs.

You can filter on band, deleted IOTA, continent, worked, not worked and confirmed IOTA.