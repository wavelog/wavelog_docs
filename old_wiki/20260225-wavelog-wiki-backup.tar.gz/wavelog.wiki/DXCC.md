Within the DXCC-Award page you can find an overview on your actual DXCC-count. Each DXCC is listed with it's bands worked on.

<img width="1324" alt="image" src="https://github.com/wavelog/wavelog/assets/1410708/74c992cb-cf91-49a7-b365-175f5e7fefe7">


The list contains all worked (confirmed and unconfirmed) DXCC entities.

You can filter on band, deleted DXCC, continent, LoTW, QSL, eQSL, QRZ.com, worked, not worked and confirmed.