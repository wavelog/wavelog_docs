# Labels
Wavelog itself is capable to create printings of labels or QSL-cards. 

Simply go to Labels at the Usermenu to the right.
QSL-Labels are listed, if they're marked as requested within QSO-Edit/Add or Logbook-Advanced