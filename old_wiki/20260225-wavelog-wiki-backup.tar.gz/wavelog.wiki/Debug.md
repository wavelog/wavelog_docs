Debug is a simple tool to help debug user installations, it shows server software, PHP version, installed PHP modules and also whether folders have been correctly set up with permissions.

To access debug the ENVIRONMENT in index.php see `define('ENVIRONMENT', 'development');` must be set to development this is the standard choice so you might not need to change anything.