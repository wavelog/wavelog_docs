
<img width="1328" alt="image" src="https://github.com/wavelog/wavelog/assets/1410708/d1ff14aa-90ea-4b9d-800e-57dc4d49389b">


The Dashboard is the page displayed right after the login. It shows the top bar menu, the map, and a list of the most recently made QSOs in the logbook, along with some high level statistics on QSOs, Countries worked, and QSL cards. 

The map shows contacts from the list of the most recently made QSOs displayed below the map. By default, this table shows 20 latest contacts. However, this number can be configured in your account settings. NOTE: The number of map plots do not need to exactly match the number of QSOs in the list, as some map plots may overlap (for example, if you have multiple contacts to the same DXCC without precise gridsquares).

### Menu options

**Logbook** takes you to a page that is the Dashboard minus the QSO, Countries and QSL references. 

**QSO** dropdown has the following:
* Live QSO - uses data from your radio to populate freq, and uses a real time clock.
* Post QSO - all information is entered manually.

**Notes** is an area for entering information that you use frequently such as frequency references and skeds. These notes can't be accessed whilst entering details in the QSO section.

**Analytics** dropdown has the following:
* Statistics provides info on QSO per year, mode and band, plus a list of satellites used.
* Gridsquares can be viewed by band or satellites, the map starts at the high level and zooms through the sub and extended squares.
* Distances worked are selected by band or satellites (not individual sats) and are displayed in a graph of distance against number of QSOs with callsigns listed at each range. Number of contacts and the detail of the furthest contact are also provided.
* Days with QSOs are broken down by year and number of days then plotted in a graph.
* DXCC Timeline shows DXCC contacts by date and prefix with a link to the details of the contact.

**Awards** breaks down QSO into DXCC, VUCC, WAS, CQ, IOTA, WAB, SOTA, and DOK with detailed listings available under each award section.

**Admin** dropdown has the following:
* Accounts enables the owner to add more than one user to the logbook which is very useful for clubs and competition stations.
* [API](https://github.com/wavelog/Wavelog/wiki/API)   
* [Station Profiles](https://github.com/wavelog/Wavelog/wiki/Station-Profiles)
* [Radio Interface](https://github.com/wavelog/Wavelog/wiki/Radio-Interface) 
* [ADIF Import/Export](https://github.com/wavelog/Wavelog/wiki/ADIF-Import---Export)
* [LoTW Import/Export](https://github.com/wavelog/Wavelog/wiki/LOTW-Import---Export) 
* [eQSL Import/Export](https://github.com/wavelog/Wavelog/wiki/eQSL-Import---Export)
* [Print Requested QSLs](https://github.com/wavelog/Wavelog/wiki/Print-Requested-QSLs)
* [Backup](https://github.com/wavelog/Wavelog/wiki/Backup)
* [Update Country Files](https://github.com/wavelog/Wavelog/wiki/Update-Country-Files)
 