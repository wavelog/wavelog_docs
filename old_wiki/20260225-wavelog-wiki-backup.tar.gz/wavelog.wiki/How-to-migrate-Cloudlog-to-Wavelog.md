## Dear Cloudlog Users

Since early 2024 we offered a tutorial here on how to migrate an existing Cloudlog installation to Wavelog. This worked well for a long time. However, as both projects have evolved independently, the codebases have diverged to a point **where a clean migration can no longer be guaranteed.**

We therefore strongly recommend against using this tutorial and instead suggest performing a fresh Wavelog installation using one of the guides in this Wiki, then manually importing your QSOs, settings and station setups. Yes, it requires a bit more effort — but you'll end up with a clean, performant Wavelog setup from day one.

If you still want to try the old migration path, the deprecated tutorial is available here: [How to migrate Cloudlog to Wavelog (deprecated)](https://github.com/wavelog/wavelog/wiki/How-to-migrate-Cloudlog-to-Wavelog-(DEPRECATED))

Vy 73 de Wavelog Dev Team