It's about time that we had some kind of style guide

Wavelog uses Bootstrap for all frontend styling plus custom CSS and Javascript to carry out missing functions.

* Section titles must be h2 tags for example "Logbook"
* Bootstrap cards can be used to contain the content of the section if suitable.

* Javascript/CSS but not be included in the sections template only in the header/footer and only shown on the sections which require it to help with load times.