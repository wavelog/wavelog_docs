Within the VUCC-Award page you can find an overview on your actual gridsquare-count. Each band is listed with worked and confirmed gridsquares. You can then click on a band, and get a list of all gridsquares worked on that band. QSL and LoTW status are also shown. 

If you click on the gridsquare, you will get a page with all the qsos you have worked within that gridsquare.