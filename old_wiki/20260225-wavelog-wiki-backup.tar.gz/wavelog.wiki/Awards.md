In this section you would find some statistics about different award-programmes like:

* [[DXCC]]
* [[SIG]]
* [[SOTA]]
* [[CQ]]
* [[DOK]]
* [[WAS]]
* [[VUCC]]
* [[IOTA]]
* [[WAP]]