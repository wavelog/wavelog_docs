Within the DOK-Award page you can find an overview on your actual DOK-count. Each DOK is listed with it's bands worked on.

The list contains all worked (confirmed and unconfirmed) DOK entities.