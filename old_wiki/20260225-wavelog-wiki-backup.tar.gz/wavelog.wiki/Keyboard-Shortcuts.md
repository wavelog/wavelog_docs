## QSO Input

* Pressing Spacebar in the callsign field moves you to the name field.