The QSO Modes pages intents to make you able to configure your modes-selection-list in QSO-Windows. Here you can set modes active to be shown in the list, or inactive to be hidden.

In past-QSO window, all modes actually listed in the [adif specs](https://adif.org/) are shown.

You also can add new modes if you want and find them suitable but keep sure to have the syntax like in adif specs defined!