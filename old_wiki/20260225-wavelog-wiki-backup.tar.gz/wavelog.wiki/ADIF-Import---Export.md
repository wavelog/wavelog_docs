# ADIF Im-/Export

With the ADIF Import/Export function it is easily possible for you to import logs from third party programs like WSJTX or other digimode-programs.
You can also export ADIF-files to other programs or logbooks.

### Hint:
Please keep in mind, that huge ADIF Files take a bit longer to import/export.
So be gently and don't upload your whole HAM-Career every day. There are - e.g. - other Solutions for adding WSJT-X QSO to Wavelog. See [https://github.com/wavelog/WaveLogGate](https://github.com/wavelog/WaveLogGate)