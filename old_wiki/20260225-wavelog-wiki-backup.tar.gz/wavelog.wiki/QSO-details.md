
![QSO details popup](https://github.com/wavelog/wavelog/assets/13950650/2ce7e4c7-4b4f-4419-9b7d-cb142f2c8c61)

The QSO details popup is accessed after clicking a callsign link anywhere in the log, be that from the dashboard, logbook page, or search results.