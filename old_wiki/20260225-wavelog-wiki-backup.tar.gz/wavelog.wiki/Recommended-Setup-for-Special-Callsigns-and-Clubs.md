This has moved to 

https://github.com/wavelog/wavelog/wiki/Clubstations