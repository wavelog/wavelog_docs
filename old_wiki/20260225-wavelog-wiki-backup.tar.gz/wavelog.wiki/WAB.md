While the Worked All Britain award system doesn't have a dedicated field in the ADIF specification, Wavelog being British made we support it using the tag "WAB:XX" replacing XX with the WAB Square.

Placing this in the comment section of a QSO will automatically make it be shown within the Awards Page. 