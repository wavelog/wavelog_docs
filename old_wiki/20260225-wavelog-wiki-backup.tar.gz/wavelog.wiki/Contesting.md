## Prelog
> [!IMPORTANT]
> **FUTURE DEVELOPMENT**  
> The contesting module becomes "legacy" in summer 2026. There is currently a new contesting in development which will replace this one. Important to say is, that the new contesting will only available for docker installations or manually on the cli (nodejs). "FTP-Only" users on cheap hostings will need to use the legacy contesting which isn't in active development anymore and just receives **minimal maintenance**.

## Overview
![Image of Contest Logging Screen](https://github.com/wavelog/wavelog/assets/13950650/5a42456f-fb89-4a8c-a089-8573d116db4a)


## Exchange Types

* None - This is for running QSOs without an exchange. Perhaps a DXPedition?
* Exchange - This is for types of exchange that is not an incrementing serial. In CQWW it's your CQ zone. In ARRL it's your power. This is not reset after QSO is logged.
* Gridsquare - exchanging maidenhead gridsquare
* Serial - Exchange in the contest is a simple serial exchange 001 etc. This will auto-increment when QSO is logged.
* Serial + Exchange - where both serial and exchange is required
* Serial + Gridsquare - where both serial and gridsquare is required

## Shortcut Keys

| Shortcut      | Function            |
| ------------- |:-------------------:|
| ALT + W       | Clears input fields |
| ESC           | Clears input fields      |
| CTRL + Enter  | Logs QSO      |
| Spacebar      | Moves you to the exchange field      |
| Enter         | Logs QSO when sent exchange exchange field is active     |

A basic duplicate check is implemented, which will tell you if the callsign is a duplicate on the same band, mode and contest.

An option to copy the received exchange into the DOK-field in the database is also available.

Feature requests will be considered, but keep in mind that this is not a full blown contest software. This is only a very basic implementation of a contest mode.