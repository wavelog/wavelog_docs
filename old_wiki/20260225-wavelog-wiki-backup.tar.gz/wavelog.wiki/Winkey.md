> [!IMPORTANT]
> Webserial will only work in Chrome, Edge and Opera. Other browsers have limited or no support for webserial.

Winkey support is very experimental due to it using WebSerial directly from the browser, at the moment it sometimes doesn't start the keyer correctly so you might want to start the keyer first with a different application then connect using the browser afterwards.

## Macro Shortcuts

| Shortcut    | Function |
| -------- | ------- |
| [MYCALL]  | The Callsign of the Station Location    |
| [CALL] | Callsign in the input     |
| [RSTS] | Sent RST     |

A few notes:
* You must be in CW mode
* You must be running via https. If you are running locally, the url must be localhost.