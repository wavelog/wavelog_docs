Global Options are settings that affect Wavelog whether you're logged in or not and over time will have more options as time goes on.

## Appearance

Wavelog has a number of appearance settings that can be changed that allows you to change how things look for all users including those not logged in.

* Theme - This allows you to select a global theme for example if you want non logged in users to see the dark theme too, this is overridden when a user logs in if they have a different choice.